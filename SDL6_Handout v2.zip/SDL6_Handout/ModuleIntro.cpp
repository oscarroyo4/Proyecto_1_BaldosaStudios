#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleIntro.h"
#include "ModuleInput.h"
#include "ModulePaoPao.h"
#include "ModuleFadeToBlack.h"


ModuleIntro::ModuleIntro()
{
	intr.PushBack({ 0, 0, 384, 224 });
	intr.PushBack({ 0, 224, 384, 224 });
	intr.PushBack({ 0, 448, 384, 224 });
	intr.PushBack({ 0, 224, 384, 224 });
	intr.speed = 0.05;
}

ModuleIntro::~ModuleIntro()
{}

bool ModuleIntro::Start()
{
	LOG("Loading intro scene");
	App->render->camera.x = 0;
	App->render->camera.y = 0;

	background = App->textures->Load("Assets/Sprites/Main/welcome.png");

	return true;
}

// UnLoad assets
bool ModuleIntro::CleanUp()
{
	LOG("Unloading intro scene");

	App->textures->Unload(background);
	App->scene_intro->Disable();

	return true;
}

// Update: draw background
update_status ModuleIntro::Update()
{
	// Draw everything --------------------------------------
	App->render->Blit(background, 0, 0, &(intr.GetCurrentFrame()), 0.75f);

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == 1)
	{
		App->fade->FadeToBlack(App->scene_intro, App->paopao, 2.5);
	}

	return UPDATE_CONTINUE;
}