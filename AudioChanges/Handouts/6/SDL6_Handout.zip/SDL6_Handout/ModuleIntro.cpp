#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleIntro.h"
#include "ModuleInput.h"
#include "ModuleSceneSpace.h"
#include "ModuleFadeToBlack.h"

ModuleIntro::ModuleIntro()
{}

ModuleIntro::~ModuleIntro()
{}

bool ModuleIntro::Start()
{
	LOG("Loading intro scene");

	background = App->textures->Load("rtype/intro.png");

	return true;
}

// UnLoad assets
bool ModuleIntro::CleanUp()
{
	LOG("Unloading intro scene");

	App->textures->Unload(background);
	App->scene_intro->Disable();

	return true;
}

// Update: draw background
update_status ModuleIntro::Update()
{
	// Draw everything --------------------------------------
	App->render->Blit(background, 0, -25, NULL);

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == 1)
	{
		App->fade->FadeToBlack(App->scene_intro, App->scene_space, 2.5);
	}

	return UPDATE_CONTINUE;
}