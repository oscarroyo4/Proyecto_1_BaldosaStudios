This is the 0.2.5 build in Fatal Fury.
In this build we can see 3 screens including the pao pao cafe, and we can play as the main character Terry Bogard.
Terry can move forward and backward, jump, kick and punch.

Controles:

D --> Move forward

A --> Move backward

Space --> Jump

F --> Punch

K --> Kick

Esc --> Quit

C --> Crouch

G --> Special Attack (Particles not working)

Group Members: Oscar Royo, Carlos de Yzaguirre, Victor Bosch, Pau Raurell.

You can find our project here: https://github.com/oscarroyo4/Proyecto_1_BaldosaStudios/wiki