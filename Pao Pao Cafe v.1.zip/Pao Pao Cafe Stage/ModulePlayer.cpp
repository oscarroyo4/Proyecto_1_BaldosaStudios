#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModulePlayer::ModulePlayer()
{
	position.x = 100;
	position.y = 220;

	// idle animation (arcade sprite sheet)
	idle.PushBack({29, 913, 61, 106});
	idle.PushBack({97, 916, 62, 105});
	idle.PushBack({165, 916, 60, 103});
	idle.speed = 0.1f;

	// walk forward animation 

	
    //backwards


	//Punch animation

	punch.PushBack({ 436, 920, 72, 100 });
	punch.PushBack({ 508, 920, 64, 101 });
	punch.PushBack({ 576, 918, 96, 103 });
	punch.speed = 0.175f;

	//Kick animation

	//Jump animation

}

ModulePlayer::~ModulePlayer()
{}

// Load assets
bool ModulePlayer::Start()
{
	LOG("Loading player textures");
	bool ret = true;
	graphicsTerry = App->textures->Load("Terry Sprites.png");
	graphicsTerry2 = App->textures->Load("Terry Sprites 2.png");
	return ret;
}

// Update: draw background
update_status ModulePlayer::Update()
{
	Animation* current_animation = &idle;

	int speed = 1;

	if(App->input->keyboard[SDL_SCANCODE_D] == 1)
	{
		current_animation = &forward;
		position.x += speed;
	}

	if (App->input->keyboard[SDL_SCANCODE_A] == 1)
	{
		current_animation = &backward;
		position.x -= speed;
	}

	if (App->input->keyboard[SDL_SCANCODE_F] == 1)
	{
		current_animation = &punch;
	}

	if (App->input->keyboard[SDL_SCANCODE_K] == 1)
	{
		current_animation = &kick;
	}

	// Draw everything --------------------------------------
	SDL_Rect r = current_animation->GetCurrentFrame();

	App->render->Blit(graphicsTerry, position.x, position.y - r.h, &r);

	return UPDATE_CONTINUE;
}