#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleBackground.h"

// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA

ModuleBackground::ModuleBackground()
{
	paopao.PushBack({ 0, 0, 619, 224 });
	paopao.PushBack({ 0, 224, 619, 224 });
	paopao.speed = 0.05f;

}

ModuleBackground::~ModuleBackground()
{}

// Load assets
bool ModuleBackground::Start()
{
	LOG("Loading background assets");
	bool ret = true;
	graphics = App->textures->Load("Pao Pao Cafe Stage.png");
	return ret;
}

// Update: draw background
update_status ModuleBackground::Update()
{
	// Draw everything --------------------------------------
	App->render->Blit(graphics, 0, 0, &(paopao.GetCurrentFrame()), 0.75f); // Pao Pao Cafe Stage animation

	return UPDATE_CONTINUE;
}