#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModulePaoPao.h"

#include "ModuleWelcomeScreen.h"
#include "ModulePlayer.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include "SDL_image/include/SDL_image.h"



ModuleWelcomeScreen::ModuleWelcomeScreen()
{
	welcome.x = 0;
	welcome.y = 0;
	welcome.h = 224;
	welcome.w = 384;
}

ModuleWelcomeScreen::~ModuleWelcomeScreen()
{}

// Load assets
bool ModuleWelcomeScreen::Start()
{
	LOG("Loading assets");
	bool ret = true;
	graphics = App->textures->Load("Assets/Sprites/Main/welcome.png");
	App->welcome_screen->Enable();
	App->scene_background->Disable();
	return ret;
}

// UnLoad assets
bool ModuleWelcomeScreen::CleanUp()
{
	LOG("Unloading welcome screen");

	SDL_DestroyTexture(graphics);
	App->welcome_screen->Disable();
	SDL_DestroyTexture(graphics);

	return true;
}

// Update: draw background
update_status ModuleWelcomeScreen::Update()
{
	// Draw everything --------------------------------------
	App->render->Blit(graphics, 0, 0, &welcome, 0.75f);

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == 1)
	{
		App->fade->FadeToBlack(App->welcome_screen, App->scene_background, 2.5);
	}

	return UPDATE_CONTINUE;
}