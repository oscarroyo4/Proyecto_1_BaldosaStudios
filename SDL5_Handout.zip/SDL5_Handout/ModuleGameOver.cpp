#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModulePaoPao.h"
#include "ModuleGameOver.h"
#include "ModuleWelcomeScreen.h"
#include "ModulePlayer.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include "SDL_image/include/SDL_image.h"



ModuleGameoverScreen::ModuleGameoverScreen()
{
	gameover.x = 0;
	gameover.y = 0;
	gameover.h = 224;
	gameover.w = 384;
}

ModuleGameoverScreen::~ModuleGameoverScreen()
{}

// Load assets
bool ModuleGameoverScreen::Start()
{
	LOG("Loading assets");
	bool ret = true;
	graphics = App->textures->Load("Assets/Sprites/Main/gameover.png");
	App->gameover_screen->Enable();
	return ret;
}

// UnLoad assets
bool ModuleGameoverScreen::CleanUp()
{
	LOG("Unloading welcome screen");

	SDL_DestroyTexture(graphics);
	App->gameover_screen->Disable();

	return true;
}

// Update: draw background
update_status ModuleGameoverScreen::Update()
{
	// Draw everything --------------------------------------
	App->render->Blit(graphics, 0, 0, &gameover, 0.75f);

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == 1)
	{
		App->fade->FadeToBlack(this, App->welcome_screen, 2.5);
	}

	return UPDATE_CONTINUE;
}